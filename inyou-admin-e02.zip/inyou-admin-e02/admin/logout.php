<?php
require __DIR__.'/bootstrap.php';
if ($_SERVER['REQUEST_METHOD']!=='POST'||!validCsrf()){http_response_code(403);exit('Acceso denegado');}
$_SESSION=[];session_destroy();header('Location: /admin/login.php');exit;
