<?php
declare(strict_types=1);
ini_set('display_errors','0');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('X-Frame-Options: DENY');
header('Cache-Control: no-store, private');
if (empty($_SERVER['HTTPS']) || $_SERVER['HTTPS'] === 'off') { http_response_code(403); exit('Se requiere HTTPS.'); }
session_name('inyou_admin');
session_set_cookie_params(['lifetime'=>0,'path'=>'/admin','secure'=>true,'httponly'=>true,'samesite'=>'Strict']);
ini_set('session.use_strict_mode','1');
session_start();
function h(?string $s):string{return htmlspecialchars((string)$s,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');}
function db():PDO {
  $path = dirname(__DIR__,2).'/inyou-private/db.php';
  // Hostinger: /home/uXXXX/domains/domain/public_html/admin -> private outside public_html
  if (!is_file($path)) { $path = dirname(__DIR__,2).'/inyou-private/db.php'; }
  if (!is_file($path)) { throw new RuntimeException('Configuración privada no disponible'); }
  $c=require $path;
  return new PDO('mysql:host='.$c['host'].';dbname='.$c['database'].';charset=utf8mb4',$c['username'],$c['password'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]);
}
function csrf():string {return $_SESSION['csrf']??=bin2hex(random_bytes(32));}
function validCsrf():bool {return isset($_POST['csrf'])&&hash_equals(csrf(),(string)$_POST['csrf']);}
function requireAuth():void {if (empty($_SESSION['admin_id'])) {header('Location: /admin/login.php');exit;}}
